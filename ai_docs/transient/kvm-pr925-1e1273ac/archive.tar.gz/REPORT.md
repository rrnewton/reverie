# Background

Linux parent-death registration requests a process-directed signal when the calling task's actual creating thread dies. https://github.com/rrnewton/reverie/pull/925 proposes an explicitly opted-in, Tool-controlled implementation. Its bounded capability and outstanding work are tracked in https://github.com/rrnewton/reverie/issues/916.

This archive records qualification evidence for producer head `1e1273ac160464be8cc03cf6bbc61af3799f8df3`, tree `0af8b89d53ad8985fe2ae96c354a1fa54ea184fb`, based on `6c79fbafa8e49e60ccc79de984b7cdca3c9b0c5c`. It is not a review approval, canonical validation, Hermit consumer result, landing record or issue-completion claim. The socket-linger cleanup defect in https://github.com/rrnewton/reverie/issues/923 remains a blocking source-review finding; passing these tests does not resolve it.

## What actually ran

The archive preserves 109 terminal guarded commands: 85 historical/positive phases and 24 mutant phases. Each has its original `START.json`, `RESULT.json` and `output.log`, plus exact technical command/source bindings. `PHASES.json` records actual return codes and command arguments. The aggregate 767.881 seconds of guard wall and 1,492.725 child CPU-seconds are historical command sums, not one uninterrupted run or one distinct test population. Test discovery with `--list` executes no tests.

- At `1ab87461`, the full library ran: **1,225 passed, zero failed**, including all 30 newly declared parent-death unit controls. Its actual library artifact was later rebuilt byte-identically at 7031 and again after final-head mutant restoration: SHA256 `d78548f04dbbef8c427044a2fe5bbe1820d28d6e1c30fb27b82cc09e98381573`, 63,040,152 bytes. This is explicit artifact carry, not another full-library execution.
- At `7031d492`, **six parent-death integration selectors and five legacy/control selectors passed**, along with Clippy and the recorded compilation checks for other backends. Workspace docs failed on two bare-URL warnings. Every actual selector/result remains in the raw records and compiled inventories.
- At final `1e1273ac`, only those two documentation URLs gained angle brackets. Formatting passed in 4.062 seconds; workspace docs with warnings denied passed in 11.066 seconds. Runtime carry from 7031 is explicit. Four final-head restored mutant controls were executed; no additional final-head full-library or six-selector suite is invented.

Successful integration records generally show the selected outer libtest result, not a separately emitted receipt for every nested native/KVM route. Frozen assertions require the routes, signal identities, observations and results described in the source; those assertions must not be relabelled as separately captured raw mode logs. An outer negative-control test may pass while intentionally observing an inner failure. Counts are always attached to their actual command and source.

## Preserved failures and repairs

| Measured head | Preserved terminal failure |
| --- | --- |
| cdc9 | Compiler errors; no runtime result. |
| 0fb | After 25 focused units and four integrations passed, retained exec failed because the fixture was dynamic; the backend refused its unsupported interpreter image. The native portion had completed, but the full integration failed. |
| 428 | Static fixture link setup failed because static libc was absent, before native/KVM execution. |
| 1ab | After the 1,225-case library and four integrations passed, the freestanding exec fixture failed at link setup because its assembly section directives placed subsequent code in the discarded GNU-stack section. |
| 909f | Retained exec passed; the first controlled pause failed with an observation-permit EINVAL. Nanosleep was not reached, and this selector has no native blocked-reference route. |
| 7031 | Six integrations and five controls passed; workspace docs failed on two new bare URLs. |

The later changes include corrected fixture setup, authentic callback lease use and two documentation link wrappers. Historical failures remain failures. The final feature also explicitly restricts enrolled exec to retained static-image authority and unsupported waits before effects; the source audit and disclosed scope changes are at https://github.com/rrnewton/reverie/issues/916#issuecomment-5975405276 and https://github.com/rrnewton/reverie/issues/916#issuecomment-5975721443. Consumer adoption is independently unqualified.

## Four causal mutants, each run once

Each production-only mutant compiled, was discovered under its actual binary, and reached its designated unchanged assertion with exit 101. Each exact source was then restored, rebuilt and its same selected control passed once. No test assertions, deadlines or tolerances changed. The 24 guarded mutant phases took 267.507 seconds in aggregate.

| Mutant | Actual detection | Restored control |
| --- | --- | --- |
| M1: omit parent-death batch events | Captured child `static_elf.rs:21461`, "creator death must publish the real signal before wake": 0 versus 1. | 1/1 passed. |
| M2: omit the blocked-mask condition from ignored-signal generation | `parent_death_tests.rs:483`, blocked default SIGWINCH matrix: true versus false. | 1/1 passed. |
| M3: discard the retained executable and resolve again | `parent_death_tests.rs:906`, exact converted exec: -2 versus 0. | 1/1 passed. |
| M4: omit retained unpublished existence | `parent_death_tests.rs:163`, actual signal-zero before publication: -3 versus 0. | 1/1 passed. |

Three observer stops remain visible independently of those product results. M1's original observer encountered the outer helper panic before its captured nested stderr and stopped. A read-only parser correction identified the already-retained intended child failure; the negative was not repeated. After M2 and M3, strict raw Git-index byte checks stopped after source restoration because cached stat metadata changed. Staged blob/mode/path entries and product source stayed identical. Original unknown-writer conclusions remain preserved; later scratch controls proved ordinary `git diff` can itself refresh the cached bytes despite `GIT_OPTIONAL_LOCKS=0`. A process-local `diff.autoRefreshIndex=false` setting then preserved inherited configuration, exact dirty/clean diff bytes and the unchanged strict byte guards. There was no persistent configuration change, alternative index or relaxed guard. Both stops, scratch observations, controller deltas, restored controls and raw preimages are retained.

## Reproducibility and publication limits

`SOURCE-REFERENCES.json` gives published commit/tree and final path/blob/SHA256 identities. Product source already on GitHub is not duplicated. Small uncommitted mutant patches, actual controllers, dependency lock, compile inventories, ELF identities, raw index audits and all selected measured records are included. `FINAL-ELF-CARRY.json` identifies the actual full-library run and final restored artifact. No binary, target directory or cache is published.

All selected original evidence files retain their exact bytes. `SELECTION.json` maps original and public hashes. `REDACTIONS.json` is empty. `EXCLUDED.json` explicitly lists omitted paths, hashes and reasons: private grants/arming prose, Chat or coordination/reviewer protocols, complete external grounding/papers and redundant product source. Technical phase records retain hashes referring to excluded private grant preimages; the public archive does not reproduce or claim to reconstruct those preimages. Their byte verification remains a local audit fact.

The selected START records contain only seven explicit Cargo/test resource settings, not full environment dumps. Pattern scanning and inspection found no credential, private-key or private-quotation match; that bounded check is not a proof that arbitrary secret formats can never exist. Private source-review packets and complete primary grounding remain separately retained.

`PUBLIC-MANIFEST.json` records every archived payload file's size and SHA256. The outer archive verification records tar-member verification and exact base64 reassembly. Concatenate numbered base64 payloads in order, decode once to obtain the gzip tar, verify its advertised SHA256, then verify every extracted file against the manifest. No command or source file in the archive needs to be executed to verify its bytes. No network publication was performed by this preparation task.
