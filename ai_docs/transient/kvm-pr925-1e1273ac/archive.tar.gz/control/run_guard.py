#!/usr/bin/env python3
"""UNARMED parent-death producer guard; requires a future exact-source root grant."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time
from datetime import datetime
from zoneinfo import ZoneInfo

SLOT = Path('/home/newton/work/dev-hermit/worktrees/slots/kvm-pdeathsig-resume-20261003')
SCRATCH = Path('/tmp/kvm-pdeathsig-qualification-plan-20261003-m4ewqtby')
EVIDENCE = SLOT / 'ignored/pdeathsig-qualification-20261003'
BRANCH = 'codex/kvm-pdeathsig-resume-20261003'
SLOT_GENERATION = 1
OWNER_PID = 1571522
OWNER_START = 730624
BOOT = '47cceadc-9970-4ca3-87b0-90121ca7e88f'

p = argparse.ArgumentParser()
p.add_argument('--authorization', type=Path, required=True)
p.add_argument('--phase', required=True)
p.add_argument('--seconds', required=True, type=float)
p.add_argument('--binding', type=Path, required=True)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
cmd = a.command[1:] if a.command[:1] == ['--'] else a.command
assert cmd and a.phase.replace('-', '').isalnum() and 0 < a.seconds <= 2400
# Refuse before slot access, mkdir, or child launch. A template is not a grant.
authorization_bytes = a.authorization.read_bytes()
authorization = json.loads(authorization_bytes)
if authorization.get('armed') is not True:
    raise SystemExit('UNARMED: final source and explicit root execution grant are required')
assert authorization['grant_reference'] and authorization['source_frozen'] is True
assert authorization['slot'] == str(SLOT)
assert authorization['slot_generation'] == SLOT_GENERATION
assert authorization['agent'] == 'native-kvm-pdeathsig-resume-01a0d5c2'
assert len(authorization['head']) == 40
phase_grant = authorization['phases'][a.phase]
assert cmd == phase_grant['argv'], 'command is not the exact granted phase argv'
assert a.seconds == phase_grant['wall_seconds'], 'phase wall bound changed'


def registered_slot():
    registry = json.loads(Path('/home/newton/work/dev-hermit/worktrees/ACTIVE.devbig014.json').read_text())
    rows = [row for row in registry['slots'] if row['slot'] == 'kvm-pdeathsig-resume-20261003']
    assert len(rows) == 1
    row = rows[0]
    assert row['generation'] == SLOT_GENERATION
    assert row['agent'] == 'native-kvm-pdeathsig-resume-01a0d5c2'
    owner = row['owner']
    assert owner['pid'] == OWNER_PID and owner['start_ticks'] == OWNER_START and owner['boot_id'] == BOOT
    checkout = [r for r in row['checkouts'] if r['repository'] == 'reverie']
    assert len(checkout) == 1
    assert checkout[0]['path'] == 'worktrees/slots/kvm-pdeathsig-resume-20261003'
    assert checkout[0]['branch'] == BRANCH
    return {'slot': row['slot'], 'generation': row['generation'], 'agent': row['agent'],
            'owner': owner, 'checkout': checkout[0]['path']}



def identity(pid):
    try:
        value = Path(f'/proc/{pid}/stat').read_text()
    except (FileNotFoundError, ProcessLookupError):
        # procfs can return ESRCH when a task exits after open but before read.
        # Like ENOENT, this means this generation is no longer observable.
        return None
    fields = value[value.rindex(')') + 2:].split()
    return {'pid': pid, 'state': fields[0], 'ppid': int(fields[1]),
            'pgid': int(fields[2]), 'sid': int(fields[3]), 'start': int(fields[19])}


def free():
    return int(subprocess.check_output(['df', '-B1', '--output=avail', '/data'], text=True).splitlines()[-1])


def git(*args):
    return subprocess.check_output(['git', '-C', str(SLOT), *args])


owner = identity(OWNER_PID)
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == BOOT
assert owner and owner['start'] == OWNER_START and owner['state'] != 'Z'
binding_bytes = a.binding.read_bytes()
binding = json.loads(binding_bytes)
HEAD = binding['head']
assert HEAD == authorization['head']
assert binding['phase'] == a.phase
assert binding['source_diff_sha256'] == phase_grant['source_diff_sha256']
assert binding['index_diff_sha256'] == phase_grant['index_diff_sha256']
slot_record = registered_slot()
assert len(HEAD) == 40 and all(c in '0123456789abcdef' for c in HEAD)
assert binding['branch'] == BRANCH and binding['slot_generation'] == SLOT_GENERATION
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('branch', '--show-current').decode().strip() == BRANCH
index_diff = git('diff', '--cached', '--binary', '--full-index', HEAD, '--')
diff = git('diff', '--binary', '--full-index', HEAD, '--')
assert hashlib.sha256(index_diff).hexdigest() == binding['index_diff_sha256']
assert hashlib.sha256(diff).hexdigest() == binding['source_diff_sha256']
# Evidence is a declared write destination, not product source. This checkout
# does not ignore ignored/, so exempt only this exact guard-owned subtree.
assert EVIDENCE == SLOT / 'ignored/pdeathsig-qualification-20261003'
assert EVIDENCE.resolve() == EVIDENCE, 'evidence path must not traverse a symlink'
untracked = git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0')
evidence_prefix = b'ignored/pdeathsig-qualification-20261003/'
assert all(not path or path.startswith(evidence_prefix) for path in untracked), 'uncommitted source must be frozen first'
assert binding['source_frozen'] is True
assert SLOT.resolve() == SLOT

# Separate phase records cannot run concurrently even under different names.
lock = (SCRATCH / 'phase.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
EVIDENCE.mkdir(parents=True, exist_ok=True)
e = EVIDENCE / a.phase
e.mkdir(exist_ok=False)
start_free = free()
cpus = sorted(os.sched_getaffinity(0))
cpus = cpus[:max(1, min(8, len(cpus) // 2))]
record = {'phase': a.phase, 'command': cmd, 'cwd': str(SLOT), 'source_head': HEAD,
          'source_diff_sha256': hashlib.sha256(diff).hexdigest(),
          'index_diff_sha256': hashlib.sha256(index_diff).hexdigest(),
          'binding_sha256': hashlib.sha256(binding_bytes).hexdigest(),
          'slot_generation': SLOT_GENERATION, 'slot_record': slot_record,
          'authorization_sha256': hashlib.sha256(authorization_bytes).hexdigest(),
          'grant_reference': authorization['grant_reference'],
          'owner': owner, 'boot_id': BOOT, 'start_free_bytes': start_free,
          'cpu_affinity': cpus, 'nice_minimum': 10, 'seconds_bound': a.seconds,
          'inherited_rlimits': {name: resource.getrlimit(value) for name, value in (
              ('RLIMIT_FSIZE', resource.RLIMIT_FSIZE), ('RLIMIT_NOFILE', resource.RLIMIT_NOFILE),
              ('RLIMIT_NPROC', resource.RLIMIT_NPROC))},
          'started_et': datetime.now(ZoneInfo('America/New_York')).strftime('%Y-%m-%d %I:%M:%S %p ET')}
if start_free < 280000000000:
    record.update(rc=91, refusal='disk below 280000000000 B admission')
    (e / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    raise SystemExit(91)


def limits():
    os.sched_setaffinity(0, cpus)
    os.setpriority(os.PRIO_PROCESS, 0, max(10, os.getpriority(os.PRIO_PROCESS, 0)))


env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(SLOT / 'target/pdeathsig-001'),
           CARGO_BUILD_JOBS='8', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
           XDG_CACHE_HOME=str(SCRATCH / 'script-cache'),
           TMPDIR=str(SCRATCH / 'tmp'), REVERIE_REQUIRE_KVM='1')
(SCRATCH / 'tmp').mkdir(exist_ok=True)
record['environment_bindings'] = {key: env[key] for key in (
    'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
    'CARGO_PROFILE_DEV_DEBUG', 'XDG_CACHE_HOME', 'TMPDIR', 'REVERIE_REQUIRE_KVM')}
start = time.monotonic()
usage_start = resource.getrusage(resource.RUSAGE_CHILDREN)
reason = None
minimum = start_free
log = e / 'output.log'
known = {}


def census(leader):
    # Capture only the owned new session or descendants of already bound PIDs.
    # Every recorded PID gets its start tick, which is rechecked before signals.
    rows = subprocess.check_output(['ps', '-e', '-o', 'pid=,ppid=,sid='], text=True)
    candidates = [tuple(map(int, line.split())) for line in rows.splitlines()]
    while True:
        before = len(known)
        for pid, ppid, sid in candidates:
            if sid == leader or ppid in known:
                info = identity(pid)
                parent = identity(ppid) if ppid in known else None
                parent_owned = parent is not None and parent['start'] == known[ppid]['start']
                if info and (sid == leader or parent_owned):
                    previous = known.get(pid)
                    if previous is None or previous['start'] == info['start']:
                        known[pid] = info
        if len(known) == before:
            break
    return [info for pid, previous in known.items()
            if (info := identity(pid)) and info['start'] == previous['start']
            and info['state'] != 'Z']


def stop_owned():
    # Never signal a PID whose generation changed; never touch another session.
    for sig in (signal.SIGTERM, signal.SIGKILL):
        for pid, previous in tuple(known.items()):
            info = identity(pid)
            if info and info['start'] == previous['start'] and info['state'] != 'Z':
                try:
                    os.kill(pid, sig)
                except ProcessLookupError:
                    pass
        if sig == signal.SIGTERM:
            time.sleep(1)


with log.open('wb') as output:
    child = subprocess.Popen(cmd, cwd=SLOT, env=env, stdout=output,
                             stderr=subprocess.STDOUT, start_new_session=True,
                             preexec_fn=limits)
    leader = identity(child.pid)
    assert leader and leader['sid'] == child.pid and leader['pgid'] == child.pid
    known[child.pid] = leader
    record['child'] = leader
    (e / 'START.json').write_text(json.dumps(record, indent=2) + '\n')
    try:
        while True:
            live = census(child.pid)
            fs = os.statvfs('/data')
            available = fs.f_bavail * fs.f_frsize
            minimum = min(minimum, available)
            try:
                registered_slot()
            except (AssertionError, KeyError, ValueError, OSError):
                reason = 'registered slot generation/owner could not be re-established'
            if available < 265000000000:
                reason = 'disk below 265000000000 B stop floor'
            elif time.monotonic() - start > a.seconds:
                reason = 'declared wall bound exceeded'
            elif log.stat().st_size > 128 * 1024 * 1024:
                reason = 'output above 128 MiB'
            elif (current_owner := identity(OWNER_PID)) is None or current_owner['start'] != OWNER_START:
                reason = 'registered owner generation changed'
            if reason:
                stop_owned()
                break
            if child.poll() is not None:
                # A command exit cannot silently leave test workers/builders alive.
                leftovers = [info for info in live if info['pid'] != child.pid]
                if leftovers:
                    reason = 'command exited with owned descendants still live'
                    stop_owned()
                break
            time.sleep(1)
    except BaseException:
        stop_owned()
        child.wait()
        raise
    child_rc = child.wait()
    remaining = census(child.pid)
if not reason:
    if git('rev-parse', 'HEAD').decode().strip() != HEAD:
        reason = 'phase changed the frozen commit'
    elif hashlib.sha256(git('diff', '--binary', '--full-index', HEAD, '--')).hexdigest() != binding['source_diff_sha256']:
        reason = 'phase changed bound source bytes'
    elif hashlib.sha256(git('diff', '--cached', '--binary', '--full-index', HEAD, '--')).hexdigest() != binding['index_diff_sha256']:
        reason = 'phase changed bound index bytes'
usage_end = resource.getrusage(resource.RUSAGE_CHILDREN)
rc = 94 if reason else (child_rc if child_rc >= 0 else 128 - child_rc)
record.update(rc=rc, child_rc=child_rc, stop_reason=reason,
              source_head_end=git('rev-parse', 'HEAD').decode().strip(),
              wall_seconds=time.monotonic() - start,
              child_user_cpu_seconds=usage_end.ru_utime - usage_start.ru_utime,
              child_system_cpu_seconds=usage_end.ru_stime - usage_start.ru_stime,
              minimum_free_bytes=minimum, end_free_bytes=free(),
              output_bytes=log.stat().st_size,
              output_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
              observed_process_generations=list(known.values()), remaining_processes=remaining)
(e / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(rc)
