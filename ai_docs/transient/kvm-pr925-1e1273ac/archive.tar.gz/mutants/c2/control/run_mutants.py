#!/usr/bin/env python3
"""Private mutation recipe. Execution requires a separate exact-head root grant.

This orchestrates the existing guard; it is not a replacement resource controller.
Every fault is restored before its positive rebuild. No refs or index are written.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
from datetime import datetime
from zoneinfo import ZoneInfo
from parse_retained_c1 import parse_retained_c1

Q = Path(__file__).resolve().parent
P = Path('/home/newton/work/dev-hermit/worktrees/slots/kvm-pdeathsig-resume-20261003')
G = Path('/tmp/kvm-pdeathsig-qualification-plan-20261003-m4ewqtby/run_guard.py')
E = P / 'ignored/pdeathsig-qualification-20261003'
BRANCH = 'codex/kvm-pdeathsig-resume-20261003'
EMPTY = hashlib.sha256(b'').hexdigest()
ET = ZoneInfo('America/New_York')
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(Path(path).read_bytes())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(P), *args], env=ENV)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--authorization', type=Path, required=True)
    args = parser.parse_args()
    auth_bytes = args.authorization.read_bytes()
    auth = json.loads(auth_bytes)
    # An unarmed template must stop before even reading or writing the checkout.
    require(auth.get('armed') is True, 'UNARMED: explicit root mutant execution grant required')
    manifest_bytes = (Q / 'MUTANTS.json').read_bytes()
    manifest = json.loads(manifest_bytes)
    plan = json.loads((Q / 'EXECUTION-PLAN.json').read_text())
    head, tree = manifest['head'], manifest['tree']
    require(auth['head'] == head and auth['tree'] == tree, 'grant source mismatch')
    require(auth['runner_sha256'] == sha(__file__), 'runner differs from root-reviewed bytes')
    require(auth['mutant_manifest_sha256'] == digest(manifest_bytes), 'mutant manifest mismatch')
    require(auth['retained_parser_sha256'] == sha(Q / 'parse_retained_m1.py'), 'retained parser changed')
    require(auth['retained_manifest_sha256'] == sha(Q / 'RETAINED-M1-MANIFEST.json'), 'retained evidence bindings changed')
    require(auth['continuation_parser_sha256'] == sha(Q / 'parse_retained_c1.py'), 'continuation parser changed')
    require(auth['continuation_manifest_sha256'] == sha(Q / 'RETAINED-C1-MANIFEST.json'), 'continuation evidence changed')
    require(auth['grant_sha256'] == sha(auth['grant_reference']), 'root grant preimage mismatch')
    require(auth['positive_terminal_sha256'] == sha(auth['positive_terminal_receipt']), 'positive receipt mismatch')
    require(auth['positive_head'] == head and auth['positive_all_passed'] is True,
            'root has not accepted terminal positive evidence at this head')
    require(auth['source_frozen'] is True and auth['sole_lane_cpu'] is True, 'ownership not granted')
    require(auth['mutants'] == ['M1', 'M2', 'M3', 'M4'], 'grant is not this exact serial sequence')
    expiry = datetime.fromisoformat(auth['expires_et'])
    require(expiry.tzinfo is not None, 'grant expiration must have explicit Eastern offset')
    require(datetime.now(ET) < expiry, 'root grant expired')
    guard_hash = (Q / 'GUARD-SHA256.txt').read_text().strip()
    require(sha(G) == guard_hash == plan['existing_guard_sha256'], 'existing guard changed')
    lock_hash = plan['lock_sha256']
    out = Q / 'execution'
    out.mkdir(exist_ok=False)
    (out / 'ROOT-AUTHORIZATION.json').write_bytes(auth_bytes)
    (out / 'ROOT-GRANT.txt').write_bytes(Path(auth['grant_reference']).read_bytes())
    (out / 'POSITIVE-TERMINAL.json').write_bytes(Path(auth['positive_terminal_receipt']).read_bytes())
    records = []
    completed = []
    active = None
    safe_to_restore = True

    def registered_identity():
        registry = json.loads(Path('/home/newton/work/dev-hermit/worktrees/ACTIVE.devbig014.json').read_text())
        rows = [r for r in registry['slots'] if r['slot'] == P.name]
        require(len(rows) == 1, 'slot not unique')
        r = rows[0]
        require(r['generation'] == 1 and r['agent'] == 'native-kvm-pdeathsig-resume-01a0d5c2', 'slot generation changed')
        owner = r['owner']
        require(owner['pid'] == 1571522 and owner['start_ticks'] == 730624 and
                owner['boot_id'] == '47cceadc-9970-4ca3-87b0-90121ca7e88f', 'owner generation changed')
        stat = Path('/proc/1571522/stat').read_text()
        fields = stat[stat.rindex(')') + 2:].split()
        require(int(fields[19]) == 730624 and fields[0] != 'Z', 'owner process is not live')
        require(Path('/proc/sys/kernel/random/boot_id').read_text().strip() == owner['boot_id'], 'boot changed')
        require(any(c['repository'] == 'reverie' and c['branch'] == BRANCH and
                    c['path'] == 'worktrees/slots/' + P.name for c in r['checkouts']), 'registered checkout changed')
        require(P.resolve() == P, 'slot is not a direct path')

    registered_identity()
    index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index_path.is_absolute():
        index_path = P / index_path
    index_before = index_path.read_bytes()
    require(digest(index_before) == '387adcb58027da640f4383f88dfe9a6881f6d3f2477b996f8e93f83267078c38', 'audited raw index preimage changed; report before execution')
    lock_before = (P / 'Cargo.lock').read_bytes()
    require(digest(lock_before) == lock_hash, 'sealed Cargo.lock mismatch')
    (out / 'INDEX.before').write_bytes(index_before)
    (out / 'Cargo.lock').write_bytes(lock_before)

    def frozen(expected_source=EMPTY):
        registered_identity()
        require(git('rev-parse', 'HEAD').decode().strip() == head, 'HEAD changed')
        require(git('rev-parse', 'HEAD^{tree}').decode().strip() == tree, 'tree changed')
        require(git('branch', '--show-current').decode().strip() == BRANCH, 'branch changed')
        require(index_path.read_bytes() == index_before, 'raw index changed; never overwrite another writer')
        require((P / 'Cargo.lock').read_bytes() == lock_before, 'Cargo.lock changed; never overwrite another writer')
        require(digest(git('diff', '--cached', '--binary', '--full-index', head, '--')) == EMPTY, 'staged change appeared')
        actual = git('diff', '--binary', '--full-index', head, '--')
        require(digest(actual) == expected_source, 'tracked source differs from exact phase composition')
        return actual

    frozen()
    history = parse_retained_c1(Q)
    require(sha(index_path) == history['new_index_preimage_sha256'], 'index changed since root audit')
    completed.append(history['completed_M1'])
    historical_negative = history['M2_negative']
    write_json(out / 'M1-M2-HISTORY-ACCEPTED.json', history)
    for item in manifest['items']:
        require(sha(P / item['path']) == item['original_sha256'], 'production preimage mismatch')
        require(sha(P / item['test_path']) == item['test_file_sha256'], 'detector source mismatch')
        require(sha(Q / item['id'] / 'ORIGINAL.bin') == item['original_sha256'], 'saved restoration bytes mismatch')
        require(sha(Q / item['id'] / 'MUTATED.bin') == item['mutated_sha256'], 'saved mutation bytes mismatch')

    def phase(name, argv, seconds, source_hash, expected_rc, binary=None):
        nonlocal safe_to_restore
        require(datetime.now(ET) < expiry, 'grant expired before phase')
        frozen(source_hash)
        require(sha(G) == guard_hash, 'guard changed')
        if binary:
            require(sha(binary['binary']) == binary['sha256'], 'ELF changed before phase')
        binding = json.loads((Q / 'BINDING-TEMPLATE.json').read_text())
        binding.update(phase=name, source_diff_sha256=source_hash, index_diff_sha256=EMPTY)
        if binary:
            binding.update(binary=binary['binary'], binary_sha256=binary['sha256'])
        authorization = json.loads((Q / 'AUTHORIZATION-TEMPLATE.json').read_text())
        authorization.update(armed=True, grant_reference=str(out / 'ROOT-GRANT.txt'),
                             grant_sha256=auth['grant_sha256'], source_frozen=True,
                             phases={name: {'argv': argv, 'wall_seconds': seconds,
                                            'source_diff_sha256': source_hash, 'index_diff_sha256': EMPTY}})
        binding_path = out / (name + '.binding.json')
        auth_path = out / (name + '.authorization.json')
        write_json(binding_path, binding)
        write_json(auth_path, authorization)
        command = ['python3', str(G), '--authorization', str(auth_path), '--phase', name,
                   '--seconds', str(seconds), '--binding', str(binding_path), '--', *argv]
        print(json.dumps({'phase': name, 'event': 'start', 'at_et': datetime.now(ET).isoformat(), 'argv': argv}), flush=True)
        # The original guard owns every payload process and all resource controls.
        # On runner interruption, let its established cleanup finish before restore.
        safe_to_restore = False
        with (out / (name + '.guard-output.log')).open('wb') as output:
            child = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT, env=ENV)
            try:
                rc = child.wait()
            except BaseException:
                prior = signal.signal(signal.SIGINT, signal.SIG_IGN)
                prior_term = signal.signal(signal.SIGTERM, signal.SIG_IGN)
                try:
                    if child.poll() is None:
                        child.send_signal(signal.SIGINT)
                    child.wait()
                finally:
                    signal.signal(signal.SIGINT, prior)
                    signal.signal(signal.SIGTERM, prior_term)
                raise
        receipt_path = E / name / 'RESULT.json'
        receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else None
        safe_to_restore = (receipt is not None and receipt.get('remaining_processes', []) == []) or not (E / name / 'START.json').exists()
        record = {'phase': name, 'guard_rc': rc, 'receipt': str(receipt_path),
                  'receipt_sha256': sha(receipt_path) if receipt else None,
                  'source_diff_sha256': source_hash, 'binary': binary, 'result': receipt}
        records.append(record)
        write_json(out / 'PHASES.json', records)
        frozen(source_hash)
        if binary:
            require(sha(binary['binary']) == binary['sha256'], 'runtime changed its ELF')
        require(receipt is not None, 'guard produced no terminal receipt; not a semantic kill')
        require(receipt.get('remaining_processes') == [] and receipt.get('stop_reason') is None,
                'guard stopped or owned descendants remain; not a semantic kill')
        require(receipt['source_head'] == head and receipt['source_head_end'] == head, 'phase source binding mismatch')
        require(rc == receipt['rc'] == receipt['child_rc'] == expected_rc, 'unexpected actual child/guard rc')
        log = E / name / 'output.log'
        require(sha(log) == receipt['output_sha256'], 'raw phase output hash mismatch')
        print(json.dumps({'phase': name, 'guard_rc': rc, 'wall_seconds': receipt['wall_seconds']}), flush=True)
        return log

    def compiled(item, name, source_hash):
        argv = ['with-proxy', 'cargo', 'test', '--locked', '-j', '8', '-p', 'reverie-kvm']
        argv += ['--test', 'static_elf'] if item['target'] == 'static_elf' else ['--lib']
        argv += ['--no-run', '--message-format=json']
        log = phase(name, argv, 2400, source_hash, 0)
        artifacts = {}
        for line in log.read_text().splitlines():
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get('reason') == 'compiler-artifact' and row.get('executable') and row.get('profile', {}).get('test') and row['target']['name'] == item['target']:
                artifacts[row['executable']] = row
        require(len(artifacts) == 1, 'missing or ambiguous compiled test artifact')
        path, artifact = next(iter(artifacts.items()))
        path = Path(path)
        require(path.resolve() == path and path.is_relative_to(P / 'target/pdeathsig-001'), 'ELF outside private target')
        binary = {'target': item['target'], 'binary': str(path), 'sha256': sha(path),
                  'bytes': path.stat().st_size, 'compiler_artifact': artifact, 'source_diff_sha256': source_hash}
        write_json(out / (name + '.ELF.json'), binary)
        return binary

    def inventory(item, name, source_hash, binary):
        log = phase(name, [binary['binary'], '--list', '--format', 'terse'], 60, source_hash, 0, binary)
        tests = [line[:-6] for line in log.read_text().splitlines() if line.endswith(': test')]
        require(tests and len(tests) == len(set(tests)), 'empty or duplicate compiled inventory')
        require(tests.count(item['selector']) == 1, 'detector not exactly once in actual inventory')
        write_json(out / (name + '.inventory.json'), {'binary': binary, 'count': len(tests), 'tests': tests})

    def test(item, name, source_hash, binary, negative):
        log = phase(name, [binary['binary'], item['selector'], '--exact', '--nocapture', '--test-threads=1'],
                    120, source_hash, 101 if negative else 0, binary)
        text = log.read_text()
        summaries = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
        require(bool(summaries), 'no actual top-level test result')
        last = summaries[-1]
        require(last[0] == ('FAILED' if negative else 'ok') and
                tuple(map(int, last[1:5])) == ((0, 1, 0, 0) if negative else (1, 0, 0, 0)),
                'exact test population differs; nested totals are not top-level passes')
        result = {'selector': item['selector'], 'summary': last, 'raw_log': str(log), 'sha256': sha(log)}
        if negative:
            panics = list(re.finditer(r"thread [^\n]*panicked at ([^\n]+):\n", text))
            require(bool(panics), 'no genuine runtime panic')
            first = panics[0]
            block = text[first.start():panics[1].start() if len(panics) > 1 else len(text)]
            filename = item['test_path'].split('reverie-kvm/', 1)[1]
            require(filename + ':' + str(item['detecting_assertion_line']) + ':' in first.group(1),
                    'first panic is not the predeclared unchanged assertion location')
            require(item['panic_anchor'] in block, 'first panic is not the predeclared semantic assertion')
            expected = {'M1': ('0', '1'), 'M2': ('true', 'false'), 'M4': ('-3', '0')}
            values = re.search(r'left:\s*(\S+)\s*\n\s*right:\s*(\S+)', block)
            require(values is not None, 'semantic assertion lacks retained left/right values')
            if item['id'] == 'M3':
                require(values.group(2) == '0' and values.group(1) != '0', 'retained-exec mutant did not fail exact success assertion')
            else:
                require(values.groups() == expected[item['id']], 'semantic assertion values differ')
            result.update(first_panic=block, first_panic_location=first.group(1), actual_left_right=values.groups())
        write_json(out / (name + '.assertion.json'), result)
        return result

    def restore(item):
        require(safe_to_restore, 'guard cleanup not proven terminal: leave exact mutant bytes for root rather than writing beneath a live process')
        path = P / item['path']
        original = (Q / item['id'] / 'ORIGINAL.bin').read_bytes()
        current = path.read_bytes()
        require(digest(current) in (item['mutated_sha256'], item['original_sha256']),
                'unexpected concurrent source mutation: preserve it for root, do not overwrite')
        if current != original:
            path.write_bytes(original)
        frozen()
        proof = {'mutant': item['id'], 'head': head, 'production_sha256': sha(path),
                 'source_diff_sha256': EMPTY, 'index_diff_sha256': EMPTY,
                 'raw_index_sha256': sha(index_path), 'lock_sha256': sha(P / 'Cargo.lock'),
                 'tests_unchanged': sha(P / item['test_path']) == item['test_file_sha256']}
        require(proof['tests_unchanged'], 'detector changed')
        write_json(out / (item['id'] + '-RESTORED.json'), proof)
        return proof

    def interrupted(signum, frame):
        raise KeyboardInterrupt('runner interrupted; restore only after original guard cleanup')

    signal.signal(signal.SIGTERM, interrupted)
    try:
        # M1 is complete; M2 negative is retained. Neither negative is launched again.
        item = manifest['items'][1]
        require(item['id'] == 'M2', 'manifest order changed')
        name = 'pd' + head[:4] + 'c2m2'
        restored_binary = compiled(item, name + 'restorebuild001', EMPTY)
        inventory(item, name + 'restorelist001', EMPTY, restored_binary)
        positive_result = test(item, name + 'positive001', EMPTY, restored_binary, False)
        completed.append({'id': 'M2', 'negative': historical_negative, 'restored_positive': positive_result})
        write_json(out / 'MUTANT-RESULTS.json', completed)
        for item in manifest['items'][2:]:
            frozen()
            active = item
            name = 'pd' + head[:4] + 'c2' + item['id'].lower()
            negative_result = None
            # finally applies to mutation/write/build/list/runtime/parser errors.
            try:
                (P / item['path']).write_bytes((Q / item['id'] / 'MUTATED.bin').read_bytes())
                changed = git('diff', '--name-only', head, '--').decode().splitlines()
                require(changed == [item['path']], 'mutation touched additional files')
                diff = git('diff', '--binary', '--full-index', head, '--')
                source_hash = digest(diff)
                (out / (item['id'] + '.applied.patch')).write_bytes(diff)
                binary = compiled(item, name + 'build001', source_hash)
                inventory(item, name + 'list001', source_hash, binary)
                negative_result = test(item, name + 'negative001', source_hash, binary, True)
            finally:
                restore(item)
                active = None
            # No retry after an unexpected red; exceptions bypass this section.
            restored_binary = compiled(item, name + 'restorebuild001', EMPTY)
            inventory(item, name + 'restorelist001', EMPTY, restored_binary)
            positive_result = test(item, name + 'positive001', EMPTY, restored_binary, False)
            completed.append({'id': item['id'], 'negative': negative_result, 'restored_positive': positive_result})
            write_json(out / 'MUTANT-RESULTS.json', completed)
        frozen()
        write_json(out / 'TERMINAL.json', {'status': 'all-four-causal-mutants-killed-and-restored-controls-passed',
                                          'head': head, 'tree': tree, 'phase_count': len(records),
                                          'mutants': completed, 'source_restored': True,
                                          'historical_guarded_phases': 9, 'M1_complete_carried': True, 'M2_negative_reused_not_rerun': True})
    except BaseException as exc:
        write_json(out / 'TERMINAL.json', {'status': 'stopped-on-first-unexpected-result', 'head': head,
                                          'error_type': type(exc).__name__, 'error': str(exc),
                                          'active_mutant': active['id'] if active else None,
                                          'phase_count': len(records), 'completed_mutants': completed,
                                          'restoration_records': sorted(x.name for x in out.glob('*-RESTORED.json'))})
        raise


if __name__ == '__main__':
    main()
