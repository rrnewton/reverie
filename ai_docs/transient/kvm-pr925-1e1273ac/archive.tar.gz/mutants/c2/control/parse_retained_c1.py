"""Read-only exact carry of completed M1 and captured M2 semantic negative."""
import hashlib
import json
from pathlib import Path
import re
from parse_retained_m1 import parse_retained_m1

HEAD = '1e1273ac160464be8cc03cf6bbc61af3799f8df3'
INDEX = '387adcb58027da640f4383f88dfe9a6881f6d3f2477b996f8e93f83267078c38'
M2_LOG = '505f7a69dee3f401b408b63048c6a073064bb2f3cfc04ab8314260ef4c720362'


def parse_retained_c1(packet):
    q = Path(packet)
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    empty = hashlib.sha256(b'').hexdigest()
    m1_negative = parse_retained_m1(q)
    for item in json.loads((q / 'RETAINED-C1-MANIFEST.json').read_text()):
        assert sha(q / item['path']) == item['sha256'], item['path']
    h = q / 'retained-c1'
    phases = json.loads((h / 'PHASES.json').read_text())
    assert [x['phase'] for x in phases] == [
        'pd1e12c1m1restorebuild001', 'pd1e12c1m1restorelist001', 'pd1e12c1m1positive001',
        'pd1e12c1m2build001', 'pd1e12c1m2list001', 'pd1e12c1m2negative001']
    for row, expected in zip(phases, [0, 0, 0, 0, 0, 101]):
        phase = row['phase']
        receipt_path = h / phase / 'RESULT.json'
        receipt = json.loads(receipt_path.read_text())
        assert sha(receipt_path) == row['receipt_sha256'] and receipt == row['result']
        assert row['guard_rc'] == receipt['rc'] == receipt['child_rc'] == expected
        assert receipt['source_head'] == receipt['source_head_end'] == HEAD
        assert receipt['stop_reason'] is None and receipt['remaining_processes'] == []
        assert sha(h / phase / 'output.log') == receipt['output_sha256']
        assert sha(h / (phase + '.binding.json')) == receipt['binding_sha256']
        assert sha(h / (phase + '.authorization.json')) == receipt['authorization_sha256']
        assert receipt['index_diff_sha256'] == empty
    for offset, stem in ((0, 'pd1e12c1m1restore'), (3, 'pd1e12c1m2')):
        build, listed, run = phases[offset:offset + 3]
        elf = json.loads((h / (stem + 'build001.ELF.json')).read_text())
        inventory = json.loads((h / (stem + 'list001.inventory.json')).read_text())
        assert listed['binary'] == run['binary'] == elf == inventory['binary']
        assert all(x['source_diff_sha256'] == build['source_diff_sha256'] for x in (listed, run))
        assert inventory['tests'].count(run['result']['command'][1]) == 1
    assert all(x['source_diff_sha256'] == empty for x in phases[:3])
    m1 = json.loads((h / 'MUTANT-RESULTS.json').read_text())
    assert len(m1) == 1 and m1[0]['id'] == 'M1'
    m1 = m1[0]
    assert m1['negative']['sha256'] == m1_negative['sha256']
    assert m1['negative']['actual_left_right'] == ['0', '1']
    pos = json.loads((h / 'pd1e12c1m1positive001.assertion.json').read_text())
    assert m1['restored_positive'] == pos
    pos_log = h / 'pd1e12c1m1positive001/output.log'
    assert sha(pos_log) == pos['sha256'] == 'cc7437398c4f0910386bc83f7dc1b23935dd9c08763dd18a15947fad031fc56d'
    summaries = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', pos_log.read_text(), re.M)
    assert summaries[-1] == ('ok', '1', '0', '0', '0', '440')
    m2 = json.loads((h / 'pd1e12c1m2negative001.assertion.json').read_text())
    log = h / 'pd1e12c1m2negative001/output.log'
    assert sha(log) == m2['sha256'] == M2_LOG
    text = log.read_text()
    panics = list(re.finditer(r"thread [^\n]*panicked at ([^\n]+):\n", text))
    assert len(panics) == 1 and panics[0].group(1) == 'reverie-kvm/src/executor/parent_death_tests.rs:483:21'
    assert 'explicit=false blocked=true observed=false before=false' in text
    assert re.search(r'left:\s*true\s*\n\s*right:\s*false', text)
    summaries = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    assert summaries == [('FAILED', '0', '1', '0', '0', '1224')]
    assert m2['actual_left_right'] == ['true', 'false']
    terminal = json.loads((h / 'TERMINAL.json').read_text())
    assert terminal['status'] == 'stopped-on-first-unexpected-result'
    assert terminal['error'] == 'raw index changed; never overwrite another writer'
    assert terminal['completed_mutants'] == [m1]
    audit = json.loads((h / 'root-index-audit/REPORT.json').read_text())
    assert audit['same_staged_entries'] and audit['source_restored'] and audit['staged_diff_empty']
    assert audit['before']['stage_sha256'] == audit['observed']['stage_sha256'] == 'adb0c57af27b0415dffd576909d77cbfe2e30b2e31e3334d7f755cea43d5acd9'
    assert audit['observed']['index_sha256'] == sha(h / 'root-index-audit/INDEX.observed') == INDEX
    assert sha(h / 'root-index-audit/before.stage') == sha(h / 'root-index-audit/observed.stage') == audit['observed']['stage_sha256']
    assert (h / 'root-index-audit/head.txt').read_text().strip() == HEAD
    assert not (h / 'root-index-audit/diff.txt').read_bytes() and not (h / 'root-index-audit/staged.txt').read_bytes()
    restoration = json.loads((h / 'M2-RESTORED.json').read_text())
    assert restoration['head'] == HEAD and restoration['raw_index_sha256'] == INDEX
    assert restoration['source_diff_sha256'] == restoration['index_diff_sha256'] == empty
    assert restoration['lock_sha256'] == '4c20c5231d9f9d019c2a48c829a10affc72643e75a9cb92a6e81aab6bf70698a'
    assert restoration['tests_unchanged']
    return {'completed_M1': m1, 'M2_negative': m2, 'M2_restored_positive': 'pending',
            'historical_index_stop': terminal, 'index_audit': audit,
            'new_index_preimage_sha256': INDEX, 'refreshing_writer': 'unknown',
            'negative_reruns': 0, 'M1_positive_reruns': 0}
