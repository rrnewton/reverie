"""Read-only interpretation of one exact retained isolation-helper log.

This is not a general relaxation of the runtime test parser. The original
M1 test is never re-executed by the continuation; all historical bytes bind.
"""
import hashlib
import json
from pathlib import Path
import re

RAW_SHA = '242ab47220f8b11f92abbf4c7a1321aa93c24ba7fce7a69b2e5dcc23941fa50f'
HEAD = '1e1273ac160464be8cc03cf6bbc61af3799f8df3'
SELECTOR = 'pdeathsig::actual_creator_death_wakes_controlled_pause_and_nanosleep'


def parse_retained_m1(packet):
    q = Path(packet)
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    files = json.loads((q / 'RETAINED-M1-MANIFEST.json').read_text())
    for row in files:
        assert sha(q / row['path']) == row['sha256'], row['path']
    retained = q / 'retained-m1'
    phases = json.loads((retained / 'PHASES.json').read_text())
    assert [row['phase'] for row in phases] == [
        'pd1e12m1build001', 'pd1e12m1list001', 'pd1e12m1negative001']
    for row, expected in zip(phases, [0, 0, 101]):
        receipt_path = retained / row['phase'] / 'RESULT.json'
        receipt = json.loads(receipt_path.read_text())
        assert sha(receipt_path) == row['receipt_sha256']
        assert row['result'] == receipt
        assert row['guard_rc'] == receipt['rc'] == receipt['child_rc'] == expected
        assert receipt['source_head'] == receipt['source_head_end'] == HEAD
        assert receipt['stop_reason'] is None and receipt['remaining_processes'] == []
        assert sha(retained / row['phase'] / 'output.log') == receipt['output_sha256']
        binding = retained / (row['phase'] + '.binding.json')
        authorization = retained / (row['phase'] + '.authorization.json')
        assert sha(binding) == receipt['binding_sha256']
        assert sha(authorization) == receipt['authorization_sha256']
        assert receipt['source_diff_sha256'] == phases[0]['source_diff_sha256']
        assert receipt['index_diff_sha256'] == hashlib.sha256(b'').hexdigest()
    negative = phases[-1]
    assert negative['result']['command'][1:] == [SELECTOR, '--exact', '--nocapture', '--test-threads=1']
    assert phases[1]['binary'] == negative['binary']
    elf = json.loads((retained / 'pd1e12m1build001.ELF.json').read_text())
    assert elf == negative['binary']
    inventory = json.loads((retained / 'pd1e12m1list001.inventory.json').read_text())
    assert inventory['binary'] == elf and inventory['tests'].count(SELECTOR) == 1
    raw = retained / 'pd1e12m1negative001/output.log'
    assert sha(raw) == RAW_SHA
    text = raw.read_text()
    # The parent prints stdout and stderr inside its later status assertion.
    # Their textual position is not cross-process chronological panic order.
    outer = re.search(r"thread '[^\n]+' \(\d+\) panicked at reverie-kvm/tests/static_elf.rs:2370:5:\n", text)
    assert outer is not None
    assert SELECTOR + ': status=Some(101) stdout=' in text
    assert text.count('\n stderr=') == 1
    nested_stderr = text.split('\n stderr=', 1)[1]
    panics = list(re.finditer(r"thread [^\n]*panicked at ([^\n]+):\n", nested_stderr))
    assert len(panics) == 4
    first = panics[0]
    first_block = nested_stderr[first.start():panics[1].start()]
    assert first.group(1) == 'reverie-kvm/tests/static_elf.rs:21461:17'
    assert 'creator death must publish the real signal before wake' in first_block
    assert re.search(r'left:\s*0\s*\n\s*right:\s*1', first_block)
    summaries = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    assert summaries == [('FAILED', '0', '1', '0', '0', '440')] * 2
    # Preserve the original parser stop and source/index/lock restoration.
    terminal = json.loads((retained / 'TERMINAL.json').read_text())
    assert terminal['status'] == 'stopped-on-first-unexpected-result'
    assert terminal['error'] == 'first panic is not the predeclared unchanged assertion location'
    restored = json.loads((retained / 'M1-RESTORED.json').read_text())
    mutant = json.loads((q / 'MUTANTS.json').read_text())['items'][0]
    assert restored['head'] == HEAD and restored['production_sha256'] == mutant['original_sha256']
    assert restored['source_diff_sha256'] == restored['index_diff_sha256'] == hashlib.sha256(b'').hexdigest()
    assert restored['tests_unchanged'] is True
    assert restored['lock_sha256'] == '4c20c5231d9f9d019c2a48c829a10affc72643e75a9cb92a6e81aab6bf70698a'
    return {
        'selector': SELECTOR, 'summary': summaries[-1], 'raw_log': str(raw),
        'sha256': RAW_SHA, 'guard_rc': 101, 'child_rc': 101,
        'wall_seconds': negative['result']['wall_seconds'],
        'interpretation': 'first panic within captured child stderr; enclosing parent status assertion is a later observer',
        'first_panic': first_block, 'first_panic_location': first.group(1),
        'actual_left_right': ['0', '1'],
        'all_nested_panic_locations': [match.group(1) for match in panics],
        'later_teardown_panics_preserved': True,
        'historical_parser_failure': terminal, 'historical_restoration': restored,
        'negative_rerun': False, 'restored_positive': 'pending',
    }
