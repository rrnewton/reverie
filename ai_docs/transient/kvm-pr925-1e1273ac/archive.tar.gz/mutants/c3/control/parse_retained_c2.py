"""Read-only carry of completed M1/M2 and the exact M3 semantic negative."""
import hashlib
import json
from pathlib import Path
import re
from parse_retained_c1 import parse_retained_c1

INDEX = '44525aed687c860a6a5b1e70f625dbf68b34486f85acac9161db30c92651fde9'


def parse_retained_c2(packet):
    q = Path(packet)
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    prior = parse_retained_c1(q)
    for item in json.loads((q / 'RETAINED-C2-MANIFEST.json').read_text()):
        assert sha(q / item['path']) == item['sha256'], item['path']
    h = q / 'retained-c2'
    phases = json.loads((h / 'PHASES.json').read_text())
    assert [x['phase'] for x in phases] == ['pd1e12c2m2restorebuild001', 'pd1e12c2m2restorelist001', 'pd1e12c2m2positive001', 'pd1e12c2m3build001', 'pd1e12c2m3list001', 'pd1e12c2m3negative001']
    for row, expected in zip(phases, [0, 0, 0, 0, 0, 101]):
        name = row['phase']; receipt_path = h / name / 'RESULT.json'
        receipt = json.loads(receipt_path.read_text())
        assert sha(receipt_path) == row['receipt_sha256'] and receipt == row['result']
        assert row['guard_rc'] == receipt['rc'] == receipt['child_rc'] == expected
        assert receipt['source_head'] == receipt['source_head_end'] == '1e1273ac160464be8cc03cf6bbc61af3799f8df3'
        assert receipt['stop_reason'] is None and receipt['remaining_processes'] == []
        assert sha(h / name / 'output.log') == receipt['output_sha256']
        assert sha(h / (name + '.binding.json')) == receipt['binding_sha256']
        assert sha(h / (name + '.authorization.json')) == receipt['authorization_sha256']
    for offset, stem in ((0, 'pd1e12c2m2restore'), (3, 'pd1e12c2m3')):
        build, listed, run = phases[offset:offset + 3]
        elf = json.loads((h / (stem + 'build001.ELF.json')).read_text())
        inventory = json.loads((h / (stem + 'list001.inventory.json')).read_text())
        assert listed['binary'] == run['binary'] == elf == inventory['binary']
        assert all(x['source_diff_sha256'] == build['source_diff_sha256'] for x in (listed, run))
        assert inventory['tests'].count(run['result']['command'][1]) == 1
    completed = json.loads((h / 'MUTANT-RESULTS.json').read_text())
    assert len(completed) == 2 and completed[0] == prior['completed_M1']
    assert completed[1]['id'] == 'M2' and completed[1]['negative'] == prior['M2_negative']
    pos = json.loads((h / 'pd1e12c2m2positive001.assertion.json').read_text())
    assert completed[1]['restored_positive'] == pos
    assert sha(h / 'pd1e12c2m2positive001/output.log') == pos['sha256']
    pattern = r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
    assert re.findall(pattern, (h / 'pd1e12c2m2positive001/output.log').read_text(), re.M)[-1] == ('ok', '1', '0', '0', '0', '1224')
    negative = json.loads((h / 'pd1e12c2m3negative001.assertion.json').read_text())
    log = h / 'pd1e12c2m3negative001/output.log'; text = log.read_text()
    assert sha(log) == negative['sha256']
    panics = re.findall(r"thread [^\n]*panicked at ([^\n]+):\n", text)
    assert panics == ['reverie-kvm/src/executor/parent_death_tests.rs:906:5']
    assert re.search(r'left:\s*-2\s*\n\s*right:\s*0', text)
    assert re.findall(pattern, text, re.M) == [('FAILED', '0', '1', '0', '0', '1224')]
    assert negative['actual_left_right'] == ['-2', '0']
    terminal = json.loads((h / 'TERMINAL.json').read_text())
    assert terminal['error'] == 'raw index changed; never overwrite another writer'
    assert terminal['completed_mutants'] == completed
    audit = json.loads((h / 'index-audit/REPORT.json').read_text())
    assert audit['same_staged_entries'] and audit['source_restored'] and audit['staged_diff_empty']
    assert audit['before']['stage_sha256'] == audit['observed']['stage_sha256'] == 'adb0c57af27b0415dffd576909d77cbfe2e30b2e31e3334d7f755cea43d5acd9'
    assert audit['observed']['index_sha256'] == sha(h / 'index-audit/INDEX.observed') == INDEX
    assert not (h / 'index-audit/diff.txt').read_bytes() and not (h / 'index-audit/staged.txt').read_bytes()
    return {'completed_M1_M2': completed, 'M3_negative': negative, 'M3_restored_positive': 'pending', 'historical_index_stop': terminal, 'index_audit': audit, 'new_index_preimage_sha256': INDEX, 'negative_reruns': 0}
